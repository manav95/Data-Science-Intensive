# CompStats
Code for a workshop on statistical interference using computational methods in Python.
